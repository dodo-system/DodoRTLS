def doGet(request, session):
	import system
	import json
	# URL da API (substitua pela URL real)
	url = "http://172.20.10.8:5000/tags"
	
	try:
	    # Fazendo a requisição HTTP GET
	    response = system.net.httpGet(url, contentType="application/json")
	    
	    # Convertendo a resposta JSON em um dicionário Python
	    data = json.loads(response)  
	    print("JSON recebido:", data)
	
	    # Pegando um valor específico, por exemplo, "Tag1"
	    tag = data.get('Tag1', 'N/A')
	
	    # Depuração: Verificar o tipo da variável tag
	    print("Tipo da variável 'tag':", type(tag))
	
	    # Se 'tag' for uma lista e tiver pelo menos dois elementos
	    if isinstance(tag, list) and len(tag) > 1:
	        system.tag.writeBlocking(
	            ["[default]API/tag_x", "[default]API/tag_y"], 
	            [tag[0], tag[1]]
	        )
	        print("Escrito em tag_x:", tag[0])
	        print("Escrito em tag_y:", tag[1])
	
	    # Se 'tag' for uma lista, mas tiver apenas um elemento
	    elif isinstance(tag, list) and len(tag) == 1:
	        system.tag.writeBlocking(
	            ["[default]API/tag_x", "[default]API/tag_y"], 
	            [tag[0], "Valor Padrão"]
	        )
	        print("Escrito em tag_x:", tag[0])
	        print("Escrito em tag_y: Valor Padrão")
	
	    # Se 'tag' não for uma lista válida
	    else:
	        system.tag.writeBlocking(
	            ["[default]API/tag_x", "[default]API/tag_y"], 
	            ["N/A", "N/A"]
	        )
	        print("Escrito em tag_x: N/A")
	        print("Escrito em tag_y: N/A")
	
	except Exception as e:
	    print("Erro na requisição:", str(e))
	    
	return {'json' : 'ok'}